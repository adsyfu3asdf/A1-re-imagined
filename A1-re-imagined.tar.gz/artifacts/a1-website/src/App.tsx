import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";

import Home from "@/pages/Home";
import Mobile from "@/pages/Mobile";
import Internet from "@/pages/Internet";
import TV from "@/pages/TV";
import Business from "@/pages/Business";
import Contact from "@/pages/Contact";
import Login from "@/pages/Login";
import Transaction from "@/pages/Transaction";
import NotFound from "@/pages/not-found";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false,
      staleTime: 5 * 60 * 1000,
    },
  },
});

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/mobile" component={Mobile} />
      <Route path="/internet" component={Internet} />
      <Route path="/tv" component={TV} />
      <Route path="/business" component={Business} />
      <Route path="/contact" component={Contact} />
      <Route path="/login" component={Login} />
      <Route path="/transaction" component={Transaction} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
