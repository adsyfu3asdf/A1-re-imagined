import { PageLayout } from "@/components/layout/PageLayout";
import { PremiumCard } from "@/components/ui/PremiumCard";
import { CheckCircle2, Info, Smartphone, Signal } from "lucide-react";
import { motion } from "framer-motion";
import { Link } from "wouter";

const plans = [
  {
    name: "A1 Промо",
    price: "19.99",
    description: "Перфектен за базова свързаност и съобщения.",
    features: ["10GB 5G интернет", "Неограничени национални разговори", "Неограничени SMS", "100 минути роуминг в ЕС"],
    highlighted: false,
  },
  {
    name: "A1 Стандарт",
    price: "29.99",
    description: "Идеалният избор за ежедневно сърфиране и стрийминг.",
    features: ["50GB 5G интернет", "Неограничени национални разговори", "Неограничени SMS", "500 минути роуминг в ЕС", "1 дигитална услуга"],
    highlighted: false,
  },
  {
    name: "A1 Unlimited",
    price: "39.99",
    description: "Абсолютна свобода без никакви компромиси.",
    features: ["Неограничен 5G интернет", "Неограничени национални разговори", "Неограничени SMS", "1000 минути роуминг в ЕС", "3 дигитални услуги", "Приоритетен достъп до мрежата"],
    highlighted: true,
  }
];

export default function Mobile() {
  return (
    <PageLayout>
      <section className="bg-secondary/30 pt-20 pb-24 border-b border-border/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white border border-border shadow-sm mb-6">
              <Signal className="w-4 h-4 text-primary" />
              <span className="text-sm font-semibold">5G Ултра</span>
            </div>
            <h1 className="text-4xl md:text-6xl font-bold tracking-tight text-foreground mb-6">
              Мобилни планове, създадени за вас
            </h1>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Усетете силата на най-надеждната мрежа в България. Неограничени възможности, премиум устройства и планове, съобразени с вашите нужди.
            </p>
          </motion.div>
        </div>
      </section>

      <section className="py-24 bg-white relative -mt-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {plans.map((plan, index) => (
              <PremiumCard 
                key={plan.name} 
                highlighted={plan.highlighted} 
                delay={index * 0.1}
                className="flex flex-col"
              >
                {plan.highlighted && (
                  <div className="absolute top-0 inset-x-0 bg-primary text-primary-foreground text-center py-1.5 text-sm font-bold tracking-wide uppercase">
                    Най-популярен
                  </div>
                )}
                <div className={`mb-8 ${plan.highlighted ? 'mt-6' : ''}`}>
                  <h3 className="text-2xl font-bold text-foreground mb-2">{plan.name}</h3>
                  <p className="text-muted-foreground h-12">{plan.description}</p>
                </div>
                <div className="mb-8">
                  <div className="flex items-baseline gap-2">
                    <span className="text-5xl font-extrabold tracking-tight text-foreground">{plan.price}</span>
                    <span className="text-muted-foreground font-medium">лв. / мес.</span>
                  </div>
                  <p className="text-sm text-muted-foreground mt-2 flex items-center gap-1">
                    <Info className="w-4 h-4" /> 24-месечен договор
                  </p>
                </div>
                
                <ul className="space-y-4 mb-10 flex-grow">
                  {plan.features.map((feature, i) => (
                    <li key={i} className="flex items-start gap-3">
                      <CheckCircle2 className={`w-5 h-5 shrink-0 ${plan.highlighted ? 'text-primary' : 'text-foreground/40'}`} />
                      <span className="font-medium text-foreground/80">{feature}</span>
                    </li>
                  ))}
                </ul>

                <Link
                  href="/transaction"
                  className={`w-full py-4 rounded-xl font-bold text-lg transition-all duration-300 text-center block ${
                    plan.highlighted 
                      ? 'bg-primary text-primary-foreground shadow-lg shadow-primary/25 hover:shadow-xl hover:-translate-y-0.5' 
                      : 'bg-secondary text-foreground hover:bg-border'
                  }`}
                >
                  Избери план
                </Link>
              </PremiumCard>
            ))}
          </div>
        </div>
      </section>

      <section className="py-24 bg-foreground text-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
            >
              <h2 className="text-3xl md:text-5xl font-bold mb-6 tracking-tight text-white">Обнови устройството си.</h2>
              <p className="text-xl text-background/70 mb-10 text-balance">
                Комбинирайте новия си A1 план с най-новите смартфони. Ексклузивни онлайн отстъпки, вноски без лихва и безплатна доставка на следващия ден.
              </p>
              <button className="px-8 py-4 rounded-xl bg-white text-foreground font-bold text-lg flex items-center justify-center gap-2 hover:bg-gray-100 transition-colors">
                <Smartphone className="w-5 h-5" /> Разгледай устройства
              </button>
            </motion.div>
            
            <div className="grid grid-cols-2 gap-6">
              {[1, 2].map((i) => (
                <div key={i} className="glass-dark p-6 rounded-3xl text-center group cursor-pointer hover:-translate-y-2 transition-transform duration-300">
                  <div className="h-48 bg-white/5 rounded-2xl mb-6 flex items-center justify-center">
                    <Smartphone className="w-16 h-16 text-white/50 group-hover:text-white transition-colors" />
                  </div>
                  <h4 className="font-bold text-white text-lg">Pro Max Series</h4>
                  <p className="text-background/60 text-sm mt-2">От 45.99 лв./мес.</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
    </PageLayout>
  );
}
