import { PageLayout } from "@/components/layout/PageLayout";
import { Link } from "wouter";
import { motion } from "framer-motion";
import CountUp from "react-countup";
import { Smartphone, Wifi, Tv, Building2, ArrowRight, CheckCircle2, ShieldCheck, Zap } from "lucide-react";
import { PremiumCard } from "@/components/ui/PremiumCard";

export default function Home() {
  return (
    <PageLayout>
      {/* Hero Section */}
      <section className="relative min-h-[90vh] flex items-center pt-20 pb-32 overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src={`${import.meta.env.BASE_URL}images/hero-bg.png`}
            alt="Hero Background"
            className="w-full h-full object-cover opacity-60"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-background/40 via-background/80 to-background" />
        </div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 w-full">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <motion.div 
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="max-w-2xl"
            >
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary font-semibold text-sm mb-6 border border-primary/20">
                <span className="w-2 h-2 rounded-full bg-primary animate-pulse" />
                Мрежа №1 в България
              </div>
              <h1 className="text-5xl sm:text-6xl lg:text-7xl font-bold tracking-tight text-foreground leading-[1.1] mb-6">
                Вашият дигитален свят,<br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-primary/60">
                  Красиво свързан.
                </span>
              </h1>
              <p className="text-lg sm:text-xl text-muted-foreground mb-10 text-balance leading-relaxed">
                Изживейте ултра-бързо 5G, премиум гигабитов интернет и телевизия от ново поколение, създадени за вашия начин на живот и бизнес.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link 
                  href="/mobile" 
                  className="px-8 py-4 rounded-xl bg-primary text-primary-foreground font-bold text-lg flex items-center justify-center gap-2 shadow-lg shadow-primary/25 hover:shadow-xl hover:shadow-primary/40 hover:-translate-y-1 transition-all duration-300"
                >
                  Разгледай офертите <ArrowRight className="w-5 h-5" />
                </Link>
                <Link 
                  href="/business" 
                  className="px-8 py-4 rounded-xl bg-white border border-border text-foreground font-semibold text-lg flex items-center justify-center gap-2 shadow-sm hover:shadow-md hover:border-primary/30 transition-all duration-300"
                >
                  За бизнеса
                </Link>
              </div>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 1, delay: 0.4 }}
              className="hidden lg:block relative h-[600px]"
            >
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-primary/5 rounded-full blur-3xl" />
              
              <div className="absolute top-10 right-10 glass p-6 rounded-3xl w-64 shadow-xl animate-bounce" style={{ animationDuration: '4s' }}>
                <div className="flex items-center gap-4 mb-4">
                  <div className="w-12 h-12 bg-primary/10 rounded-2xl flex items-center justify-center text-primary">
                    <Zap className="w-6 h-6" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground font-medium">5G Мрежа</p>
                    <p className="font-bold text-foreground">Ултра Бързо</p>
                  </div>
                </div>
                <div className="h-2 w-full bg-secondary rounded-full overflow-hidden">
                  <div className="h-full bg-primary w-[95%]" />
                </div>
              </div>

              <div className="absolute bottom-20 left-0 glass p-6 rounded-3xl w-72 shadow-xl animate-bounce" style={{ animationDuration: '5s', animationDelay: '1s' }}>
                <div className="flex items-center gap-4 mb-2">
                  <div className="w-12 h-12 bg-green-500/10 rounded-2xl flex items-center justify-center text-green-600">
                    <ShieldCheck className="w-6 h-6" />
                  </div>
                  <div>
                    <p className="font-bold text-foreground text-lg">Сигурно и Надеждно</p>
                  </div>
                </div>
                <p className="text-sm text-muted-foreground mt-2">Защита на над 5 милиона устройства в цялата страна.</p>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-12 bg-white border-y border-border/50 relative z-20 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 divide-x divide-border/50">
            <div className="text-center px-4">
              <p className="text-4xl font-bold text-foreground mb-1">
                <CountUp end={5} duration={2.5} suffix="М+" />
              </p>
              <p className="text-sm font-medium text-muted-foreground uppercase tracking-wider">Активни клиенти</p>
            </div>
            <div className="text-center px-4">
              <p className="text-4xl font-bold text-foreground mb-1">
                <CountUp end={99} decimals={1} duration={2.5} suffix="%" />
              </p>
              <p className="text-sm font-medium text-muted-foreground uppercase tracking-wider">Покритие</p>
            </div>
            <div className="text-center px-4">
              <p className="text-4xl font-bold text-foreground mb-1">
                <CountUp end={1000} duration={2.5} suffix="+" />
              </p>
              <p className="text-sm font-medium text-muted-foreground uppercase tracking-wider">Mbps скорост</p>
            </div>
            <div className="text-center px-4">
              <p className="text-4xl font-bold text-foreground mb-1">
                <CountUp end={20} duration={2.5} suffix="+" />
              </p>
              <p className="text-sm font-medium text-muted-foreground uppercase tracking-wider">Години опит</p>
            </div>
          </div>
        </div>
      </section>

      {/* Quick Access Services */}
      <section className="py-32 bg-secondary/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-20">
            <h2 className="text-3xl md:text-5xl font-bold text-foreground mb-6 tracking-tight">Всичко необходимо на едно място.</h2>
            <p className="text-lg text-muted-foreground">Открийте нашите премиум услуги, създадени да ви поддържат свързани, забавлявани и продуктивни.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Link href="/mobile">
              <PremiumCard className="h-full flex flex-col items-center text-center cursor-pointer group" delay={0.1}>
                <div className="w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center text-primary mb-6 group-hover:scale-110 group-hover:bg-primary group-hover:text-white transition-all duration-300">
                  <Smartphone className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-bold mb-3">Мобилни планове</h3>
                <p className="text-muted-foreground mb-6 flex-grow">Неограничена 5G свързаност за вашия начин на живот.</p>
                <span className="text-primary font-semibold flex items-center gap-1 group-hover:gap-2 transition-all">Виж плановете <ArrowRight className="w-4 h-4" /></span>
              </PremiumCard>
            </Link>

            <Link href="/internet">
              <PremiumCard className="h-full flex flex-col items-center text-center cursor-pointer group" delay={0.2}>
                <div className="w-16 h-16 bg-blue-500/10 rounded-2xl flex items-center justify-center text-blue-600 mb-6 group-hover:scale-110 group-hover:bg-blue-600 group-hover:text-white transition-all duration-300">
                  <Wifi className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-bold mb-3">Оптичен интернет</h3>
                <p className="text-muted-foreground mb-6 flex-grow">Ултра-бърза гигабитова скорост за вашия дом.</p>
                <span className="text-blue-600 font-semibold flex items-center gap-1 group-hover:gap-2 transition-all">Провери покритие <ArrowRight className="w-4 h-4" /></span>
              </PremiumCard>
            </Link>

            <Link href="/tv">
              <PremiumCard className="h-full flex flex-col items-center text-center cursor-pointer group" delay={0.3}>
                <div className="w-16 h-16 bg-purple-500/10 rounded-2xl flex items-center justify-center text-purple-600 mb-6 group-hover:scale-110 group-hover:bg-purple-600 group-hover:text-white transition-all duration-300">
                  <Tv className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-bold mb-3">Xplore TV</h3>
                <p className="text-muted-foreground mb-6 flex-grow">Телевизия от ново поколение с умни функции.</p>
                <span className="text-purple-600 font-semibold flex items-center gap-1 group-hover:gap-2 transition-all">Разгледай TV <ArrowRight className="w-4 h-4" /></span>
              </PremiumCard>
            </Link>

            <Link href="/business">
              <PremiumCard className="h-full flex flex-col items-center text-center cursor-pointer group" delay={0.4}>
                <div className="w-16 h-16 bg-emerald-500/10 rounded-2xl flex items-center justify-center text-emerald-600 mb-6 group-hover:scale-110 group-hover:bg-emerald-600 group-hover:text-white transition-all duration-300">
                  <Building2 className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-bold mb-3">Бизнес</h3>
                <p className="text-muted-foreground mb-6 flex-grow">IT и телеком решения за предприятия.</p>
                <span className="text-emerald-600 font-semibold flex items-center gap-1 group-hover:gap-2 transition-all">Виж решенията <ArrowRight className="w-4 h-4" /></span>
              </PremiumCard>
            </Link>
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-32 bg-white relative overflow-hidden">
        <div className="absolute right-0 top-0 w-1/3 h-full bg-primary/5 rounded-l-full blur-3xl -z-10" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
            <motion.div 
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
            >
              <h2 className="text-3xl md:text-5xl font-bold text-foreground mb-6 tracking-tight">Разликата с A1.</h2>
              <p className="text-lg text-muted-foreground mb-10">Ние надхвърляме простата свързаност. Изграждаме инфраструктурата, която захранва вашето утре.</p>
              
              <div className="space-y-6">
                {[
                  "Национална 5G мрежа, носител на награди.",
                  "Денонощна премиум поддръжка на клиенти.",
                  "Ексклузивни отстъпки за хардуер и смарт устройства.",
                  "Иновативни приложения за дигитален начин на живот."
                ].map((text, i) => (
                  <div key={i} className="flex items-start gap-4">
                    <CheckCircle2 className="w-6 h-6 text-primary shrink-0 mt-1" />
                    <p className="text-foreground text-lg font-medium">{text}</p>
                  </div>
                ))}
              </div>
              
              <Link 
                href="/mobile" 
                className="inline-flex mt-12 px-8 py-4 rounded-xl bg-foreground text-background font-bold text-lg items-center justify-center gap-2 hover:bg-foreground/90 transition-all duration-300"
              >
                Присъединете се към A1
              </Link>
            </motion.div>
            
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="relative"
            >
              <img 
                src="https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=800&q=80" 
                alt="Човек използва мобилен телефон" 
                className="rounded-3xl shadow-2xl object-cover h-[600px] w-full"
              />
              <div className="absolute inset-0 rounded-3xl ring-1 ring-inset ring-black/10" />
            </motion.div>
          </div>
        </div>
      </section>
    </PageLayout>
  );
}
