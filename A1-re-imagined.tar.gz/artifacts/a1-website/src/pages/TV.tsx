import { PageLayout } from "@/components/layout/PageLayout";
import { PremiumCard } from "@/components/ui/PremiumCard";
import { Tv, PlaySquare, MonitorSmartphone, Plus } from "lucide-react";
import { motion } from "framer-motion";
import { Link } from "wouter";

export default function TV() {
  return (
    <PageLayout>
      <section className="bg-foreground text-background py-24 lg:py-32 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-[800px] h-[800px] bg-purple-600/20 rounded-full blur-[120px] -translate-y-1/2 translate-x-1/3 opacity-50" />
        <div className="absolute bottom-0 left-0 w-[600px] h-[600px] bg-primary/20 rounded-full blur-[100px] translate-y-1/3 -translate-x-1/4 opacity-50" />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="max-w-3xl mx-auto"
          >
            <div className="inline-flex items-center gap-2 px-5 py-2 rounded-full glass-dark text-white font-semibold text-sm mb-8 border-white/20">
              <Tv className="w-4 h-4 text-purple-400" />
              A1 Xplore TV
            </div>
            <h1 className="text-4xl sm:text-6xl font-bold tracking-tight text-white mb-6">
              Забавлението, преосмислено.
            </h1>
            <p className="text-xl text-background/70 mb-10 text-balance leading-relaxed">
              Трансформирайте всекидневната си с брилянтно 4K качество, интелигентни препоръки и интерактивни функции. Гледайте каквото искате, когато искате.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link
                href="/transaction"
                className="px-8 py-4 rounded-xl bg-primary text-white font-bold text-lg shadow-lg shadow-primary/30 hover:shadow-primary/50 transition-all hover:-translate-y-1"
              >
                Виж пакетите
              </Link>
              <button className="px-8 py-4 rounded-xl bg-white/10 text-white border border-white/20 font-bold text-lg hover:bg-white/20 transition-all">
                Открий функциите
              </button>
            </div>
          </motion.div>
        </div>
      </section>

      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <PremiumCard className="bg-secondary/30">
              <div className="h-12 w-12 bg-white rounded-xl flex items-center justify-center shadow-sm mb-6">
                <PlaySquare className="w-6 h-6 text-purple-600" />
              </div>
              <h3 className="text-2xl font-bold mb-4">Интерактивни функции</h3>
              <p className="text-muted-foreground mb-6">Наваксайте пропуснати предавания до 7 дни назад. Поставете на пауза, превъртете назад и записвайте любимите си моменти от телевизията на живо само с един клик.</p>
              <ul className="space-y-2">
                <li className="flex items-center gap-2 font-medium"><Plus className="w-4 h-4 text-primary" /> 7-дневен catch-up</li>
                <li className="flex items-center gap-2 font-medium"><Plus className="w-4 h-4 text-primary" /> Облачен запис</li>
              </ul>
            </PremiumCard>

            <PremiumCard className="bg-secondary/30">
              <div className="h-12 w-12 bg-white rounded-xl flex items-center justify-center shadow-sm mb-6">
                <MonitorSmartphone className="w-6 h-6 text-blue-600" />
              </div>
              <h3 className="text-2xl font-bold mb-4">Мулти-екран изживяване</h3>
              <p className="text-muted-foreground mb-6">Вземете телевизията си навсякъде. Гледайте на смартфон, таблет или лаптоп чрез приложението A1 Xplore TV навсякъде в ЕС.</p>
              <ul className="space-y-2">
                <li className="flex items-center gap-2 font-medium"><Plus className="w-4 h-4 text-primary" /> Приложение за Smart TV</li>
                <li className="flex items-center gap-2 font-medium"><Plus className="w-4 h-4 text-primary" /> Мобилно и таблетно приложение</li>
              </ul>
            </PremiumCard>
          </div>
        </div>
      </section>
    </PageLayout>
  );
}
