import { PageLayout } from "@/components/layout/PageLayout";
import { motion } from "framer-motion";
import { Building2, Cloud, Shield, Headset, ArrowRight } from "lucide-react";
import { PremiumCard } from "@/components/ui/PremiumCard";
import { Link } from "wouter";

export default function Business() {
  return (
    <PageLayout>
      <section className="relative min-h-[70vh] flex items-center pt-20 pb-20 overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src={`${import.meta.env.BASE_URL}images/business-abstract.png`}
            alt="Бизнес абстракция"
            className="w-full h-full object-cover opacity-30"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-background via-background/95 to-background/40" />
        </div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 w-full">
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="max-w-2xl"
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-emerald-500/10 text-emerald-600 font-semibold text-sm mb-6">
              <Building2 className="w-4 h-4" />
              A1 Бизнес решения
            </div>
            <h1 className="text-5xl lg:text-6xl font-bold tracking-tight text-foreground leading-[1.1] mb-6">
              Захранваме бъдещето на вашето предприятие.
            </h1>
            <p className="text-xl text-muted-foreground mb-10 text-balance">
              Сигурна инфраструктура, облачни изчисления и персонализирана свързаност, проектирани да ускорят растежа на вашия бизнес.
            </p>
            <Link
              href="/contact"
              className="inline-flex px-8 py-4 rounded-xl bg-foreground text-background font-bold text-lg hover:bg-foreground/90 transition-all duration-300 shadow-xl"
            >
              Свържете се с експерт
            </Link>
          </motion.div>
        </div>
      </section>

      <section className="py-24 bg-white border-t border-border/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <PremiumCard>
              <div className="w-14 h-14 bg-emerald-500/10 rounded-2xl flex items-center justify-center text-emerald-600 mb-6">
                <Cloud className="w-7 h-7" />
              </div>
              <h3 className="text-xl font-bold mb-3">Облак и дата центрове</h3>
              <p className="text-muted-foreground mb-6">Сигурни, мащабируеми и локализирани решения за дата центрове. Виртуални сървъри, резервно копиране и аварийно възстановяване в най-добрите съоръжения в България.</p>
              <a href="#" className="text-emerald-600 font-semibold flex items-center gap-2 hover:underline">Разгледай Cloud <ArrowRight className="w-4 h-4" /></a>
            </PremiumCard>

            <PremiumCard>
              <div className="w-14 h-14 bg-blue-500/10 rounded-2xl flex items-center justify-center text-blue-600 mb-6">
                <Shield className="w-7 h-7" />
              </div>
              <h3 className="text-xl font-bold mb-3">Киберсигурност</h3>
              <p className="text-muted-foreground mb-6">Корпоративна защита срещу DDoS атаки, управлявани услуги за защитна стена и защита на крайни точки, за да пазите данните си в безопасност.</p>
              <a href="#" className="text-blue-600 font-semibold flex items-center gap-2 hover:underline">Разгледай сигурността <ArrowRight className="w-4 h-4" /></a>
            </PremiumCard>

            <PremiumCard>
              <div className="w-14 h-14 bg-primary/10 rounded-2xl flex items-center justify-center text-primary mb-6">
                <Headset className="w-7 h-7" />
              </div>
              <h3 className="text-xl font-bold mb-3">Персонална поддръжка</h3>
              <p className="text-muted-foreground mb-6">Всеки корпоративен клиент получава личен мениджър на акаунт и денонощна приоритетна техническа поддръжка с гарантирани SLA.</p>
              <a href="#" className="text-primary font-semibold flex items-center gap-2 hover:underline">Научи повече <ArrowRight className="w-4 h-4" /></a>
            </PremiumCard>
          </div>
        </div>
      </section>
    </PageLayout>
  );
}
