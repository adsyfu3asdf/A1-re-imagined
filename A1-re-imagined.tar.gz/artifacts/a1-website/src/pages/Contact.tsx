import { PageLayout } from "@/components/layout/PageLayout";
import { PremiumCard } from "@/components/ui/PremiumCard";
import { MapPin, Phone, Clock } from "lucide-react";
import { useState } from "react";
import { useSubmitContact } from "@/hooks/use-contact";
import { useToast } from "@/hooks/use-toast";
import { motion } from "framer-motion";

export default function Contact() {
  const [formData, setFormData] = useState({ name: "", email: "", subject: "", message: "" });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const submitMutation = useSubmitContact();
  const { toast } = useToast();

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
    if (errors[e.target.name]) {
      setErrors({ ...errors, [e.target.name]: "" });
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrors({});
    
    submitMutation.mutate(formData, {
      onSuccess: (data) => {
        toast({ title: "Успешно", description: data.message });
        setFormData({ name: "", email: "", subject: "", message: "" });
      },
      onError: (err: any) => {
        if (err.errors) {
          const newErrors: Record<string, string> = {};
          err.errors.forEach((e: any) => { newErrors[e.path[0]] = e.message; });
          setErrors(newErrors);
        } else {
          toast({ title: "Грешка", description: err.message || "Неуспешно изпращане на формата", variant: "destructive" });
        }
      }
    });
  };

  return (
    <PageLayout>
      <section className="bg-secondary/30 pt-20 pb-24 border-b border-border/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
            className="text-4xl md:text-5xl font-bold tracking-tight text-foreground mb-6"
          >
            Тук сме, за да ви помогнем.
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
            className="text-xl text-muted-foreground max-w-2xl mx-auto"
          >
            Свържете се с нашия екип за обслужване на клиенти по телефон, имейл или посетете някой от нашите магазини.
          </motion.p>
        </div>
      </section>

      <section className="py-24 bg-white relative -mt-10 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            
            <div className="lg:col-span-1 space-y-6">
              <PremiumCard className="p-6">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center text-primary shrink-0">
                    <Phone className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-bold text-lg mb-1">Обадете ни се</h4>
                    <p className="text-muted-foreground text-sm mb-2">Безплатно от мрежа A1</p>
                    <a href="tel:147" className="text-2xl font-bold text-foreground hover:text-primary transition-colors">*147</a>
                    <p className="text-foreground mt-2 font-medium">0700 10 147 <span className="text-muted-foreground text-sm font-normal">(от други мрежи)</span></p>
                  </div>
                </div>
              </PremiumCard>

              <PremiumCard className="p-6">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 bg-blue-500/10 rounded-full flex items-center justify-center text-blue-600 shrink-0">
                    <MapPin className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-bold text-lg mb-1">Намери магазин</h4>
                    <p className="text-muted-foreground text-sm mb-4">Посетете някой от нашите 200+ обекта в цяла България.</p>
                    <button className="text-blue-600 font-semibold hover:underline">Търсач на магазини</button>
                  </div>
                </div>
              </PremiumCard>

              <PremiumCard className="p-6 bg-foreground text-background">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center text-white shrink-0">
                    <Clock className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-bold text-lg mb-1 text-white">Работно време</h4>
                    <p className="text-background/70 text-sm mb-1">Техническа поддръжка:</p>
                    <p className="text-white font-semibold mb-3">24/7/365</p>
                    <p className="text-background/70 text-sm mb-1">Общи запитвания:</p>
                    <p className="text-white font-semibold">Пон-Нед, 08:00 - 22:00</p>
                  </div>
                </div>
              </PremiumCard>
            </div>

            <div className="lg:col-span-2">
              <PremiumCard className="h-full">
                <h3 className="text-2xl font-bold mb-6">Изпратете ни съобщение</h3>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-sm font-semibold text-foreground">Имe</label>
                      <input 
                        type="text" name="name" value={formData.name} onChange={handleChange}
                        className={`w-full px-4 py-3 rounded-xl border bg-background focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all ${errors.name ? 'border-destructive' : 'border-border'}`}
                        placeholder="Иван Иванов"
                      />
                      {errors.name && <p className="text-destructive text-sm">{errors.name}</p>}
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-semibold text-foreground">Имейл</label>
                      <input 
                        type="email" name="email" value={formData.email} onChange={handleChange}
                        className={`w-full px-4 py-3 rounded-xl border bg-background focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all ${errors.email ? 'border-destructive' : 'border-border'}`}
                        placeholder="ivan@example.com"
                      />
                      {errors.email && <p className="text-destructive text-sm">{errors.email}</p>}
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-sm font-semibold text-foreground">Тема</label>
                    <input 
                      type="text" name="subject" value={formData.subject} onChange={handleChange}
                      className={`w-full px-4 py-3 rounded-xl border bg-background focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all ${errors.subject ? 'border-destructive' : 'border-border'}`}
                      placeholder="Как можем да ви помогнем?"
                    />
                    {errors.subject && <p className="text-destructive text-sm">{errors.subject}</p>}
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-semibold text-foreground">Съобщение</label>
                    <textarea 
                      name="message" value={formData.message} onChange={handleChange} rows={5}
                      className={`w-full px-4 py-3 rounded-xl border bg-background focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all resize-none ${errors.message ? 'border-destructive' : 'border-border'}`}
                      placeholder="Разкажете ни повече за вашето запитване..."
                    />
                    {errors.message && <p className="text-destructive text-sm">{errors.message}</p>}
                  </div>

                  <button 
                    type="submit" disabled={submitMutation.isPending}
                    className="w-full md:w-auto px-8 py-4 rounded-xl bg-primary text-white font-bold shadow-lg shadow-primary/25 hover:shadow-xl hover:-translate-y-0.5 transition-all disabled:opacity-50 disabled:transform-none"
                  >
                    {submitMutation.isPending ? "Изпращане..." : "Изпрати съобщение"}
                  </button>
                </form>
              </PremiumCard>
            </div>

          </div>
        </div>
      </section>
    </PageLayout>
  );
}
