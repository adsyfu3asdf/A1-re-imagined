import { useState } from "react";
import { Link, useLocation } from "wouter";
import { motion } from "framer-motion";
import { Eye, EyeOff, User, Lock, Smartphone, ChevronRight } from "lucide-react";

export default function Login() {
  const [, navigate] = useLocation();
  const [tab, setTab] = useState<"personal" | "business">("personal");
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({ phone: "", password: "" });
  const [error, setError] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (!formData.phone || !formData.password) {
      setError("Моля, попълнете всички полета.");
      return;
    }

    setLoading(true);
    // Simulate auth delay
    setTimeout(() => {
      setLoading(false);
      navigate("/transaction");
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-secondary/30 flex items-center justify-center px-4 py-16">
      <div className="w-full max-w-md">
        {/* Logo */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-10"
        >
          <Link href="/" className="inline-flex items-center gap-3 group">
            <div className="w-14 h-14 bg-primary rounded-2xl flex items-center justify-center text-white font-bold text-2xl shadow-lg shadow-primary/30 group-hover:scale-105 transition-transform">
              A1
            </div>
            <span className="text-2xl font-bold text-foreground">България</span>
          </Link>
          <p className="text-muted-foreground mt-4">Влезте в своя акаунт</p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="bg-white rounded-3xl shadow-xl shadow-black/5 border border-border/50 overflow-hidden"
        >
          {/* Tabs */}
          <div className="flex border-b border-border/50">
            <button
              onClick={() => setTab("personal")}
              className={`flex-1 py-4 text-sm font-semibold transition-all ${
                tab === "personal"
                  ? "text-primary border-b-2 border-primary bg-primary/5"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              Личен акаунт
            </button>
            <button
              onClick={() => setTab("business")}
              className={`flex-1 py-4 text-sm font-semibold transition-all ${
                tab === "business"
                  ? "text-primary border-b-2 border-primary bg-primary/5"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              Бизнес акаунт
            </button>
          </div>

          <div className="p-8">
            <form onSubmit={handleSubmit} className="space-y-5">
              {/* Phone / Username */}
              <div className="space-y-2">
                <label className="text-sm font-semibold text-foreground">
                  {tab === "personal" ? "Мобилен номер или имейл" : "ЕИК / Имейл"}
                </label>
                <div className="relative">
                  <div className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground">
                    {tab === "personal" ? <Smartphone className="w-5 h-5" /> : <User className="w-5 h-5" />}
                  </div>
                  <input
                    type="text"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full pl-12 pr-4 py-3.5 rounded-xl border border-border bg-background focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all"
                    placeholder={tab === "personal" ? "+359 8XX XXX XXX" : "123456789"}
                  />
                </div>
              </div>

              {/* Password */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-sm font-semibold text-foreground">Парола</label>
                  <a href="#" className="text-sm text-primary hover:underline font-medium">Забравена парола?</a>
                </div>
                <div className="relative">
                  <div className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground">
                    <Lock className="w-5 h-5" />
                  </div>
                  <input
                    type={showPass ? "text" : "password"}
                    value={formData.password}
                    onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                    className="w-full pl-12 pr-12 py-3.5 rounded-xl border border-border bg-background focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all"
                    placeholder="Въведете парола"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPass(!showPass)}
                    className="absolute right-4 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                  >
                    {showPass ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </div>

              {/* Error */}
              {error && (
                <motion.p
                  initial={{ opacity: 0, y: -5 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="text-destructive text-sm font-medium bg-destructive/5 px-4 py-3 rounded-xl border border-destructive/20"
                >
                  {error}
                </motion.p>
              )}

              {/* Submit */}
              <button
                type="submit"
                disabled={loading}
                className="w-full py-4 rounded-xl bg-primary text-white font-bold text-lg shadow-lg shadow-primary/25 hover:shadow-xl hover:-translate-y-0.5 transition-all disabled:opacity-70 disabled:transform-none flex items-center justify-center gap-2"
              >
                {loading ? (
                  <>
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    Влизане...
                  </>
                ) : (
                  <>
                    Влез в акаунта <ChevronRight className="w-5 h-5" />
                  </>
                )}
              </button>
            </form>

            {/* Divider */}
            <div className="relative my-6">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-border/50" />
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="px-4 bg-white text-muted-foreground">или</span>
              </div>
            </div>

            {/* QR / App login */}
            <button className="w-full py-3.5 rounded-xl border border-border text-foreground font-semibold hover:bg-secondary/50 transition-all flex items-center justify-center gap-3">
              <Smartphone className="w-5 h-5 text-primary" />
              Влез с A1 мобилното приложение
            </button>

            {/* Register */}
            <p className="text-center text-sm text-muted-foreground mt-6">
              Нямате акаунт?{" "}
              <a href="#" className="text-primary font-semibold hover:underline">
                Регистрирайте се
              </a>
            </p>
          </div>
        </motion.div>

        {/* Security notice */}
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4 }}
          className="text-center text-xs text-muted-foreground mt-6"
        >
          🔒 Връзката е защитена със SSL криптиране. Вашите данни са в безопасност.
        </motion.p>
      </div>
    </div>
  );
}
