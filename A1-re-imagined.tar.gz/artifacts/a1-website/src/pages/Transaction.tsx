import { useState } from "react";
import { Link, useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { CreditCard, Lock, CheckCircle2, ArrowLeft, Wifi, Smartphone, Tv, ChevronDown } from "lucide-react";

const services = [
  { id: "mobile", label: "A1 Unlimited Мобилен план", price: 39.99, icon: Smartphone, color: "text-primary" },
  { id: "internet", label: "A1 Fiber 500 Mbps интернет", price: 27.99, icon: Wifi, color: "text-blue-600" },
  { id: "tv", label: "A1 Xplore TV пакет", price: 19.99, icon: Tv, color: "text-purple-600" },
  { id: "bill", label: "Плащане на текуща сметка", price: 0, icon: CreditCard, color: "text-emerald-600" },
];

type Step = "select" | "details" | "confirm" | "success";

export default function Transaction() {
  const [, navigate] = useLocation();
  const [step, setStep] = useState<Step>("select");
  const [selectedService, setSelectedService] = useState(services[0]);
  const [customAmount, setCustomAmount] = useState("39.99");
  const [loading, setLoading] = useState(false);
  const [cardData, setCardData] = useState({
    number: "",
    name: "",
    expiry: "",
    cvv: "",
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const formatCard = (val: string) =>
    val.replace(/\D/g, "").slice(0, 16).replace(/(.{4})/g, "$1 ").trim();

  const formatExpiry = (val: string) => {
    const d = val.replace(/\D/g, "").slice(0, 4);
    return d.length >= 3 ? `${d.slice(0, 2)}/${d.slice(2)}` : d;
  };

  const validate = () => {
    const e: Record<string, string> = {};
    if (cardData.number.replace(/\s/g, "").length < 16) e.number = "Въведете валиден номер на карта.";
    if (!cardData.name.trim()) e.name = "Въведете името на картодържателя.";
    if (cardData.expiry.length < 5) e.expiry = "Въведете валидна дата на изтичане.";
    if (cardData.cvv.length < 3) e.cvv = "Въведете валиден CVV.";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handlePay = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setStep("success");
    }, 2200);
  };

  const amount = selectedService.id === "bill" ? parseFloat(customAmount) || 0 : selectedService.price;

  return (
    <div className="min-h-screen bg-secondary/30 py-10 px-4">
      <div className="max-w-2xl mx-auto">

        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center justify-between mb-8"
        >
          <Link href="/" className="flex items-center gap-2 group">
            <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center text-white font-bold shadow-lg shadow-primary/25 group-hover:scale-105 transition-transform">
              A1
            </div>
            <span className="font-bold text-foreground text-lg">България</span>
          </Link>
          {step !== "success" && (
            <button
              onClick={() => step === "select" ? navigate("/") : setStep(step === "details" ? "select" : "details")}
              className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
            >
              <ArrowLeft className="w-4 h-4" /> Назад
            </button>
          )}
        </motion.div>

        {/* Progress Steps */}
        {step !== "success" && (
          <div className="flex items-center gap-2 mb-8">
            {(["select", "details", "confirm"] as Step[]).map((s, i) => {
              const steps: Step[] = ["select", "details", "confirm"];
              const current = steps.indexOf(step);
              const isActive = steps.indexOf(s) <= current;
              return (
                <div key={s} className="flex items-center gap-2 flex-1">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold transition-all ${
                    isActive ? "bg-primary text-white shadow-md shadow-primary/25" : "bg-white border-2 border-border text-muted-foreground"
                  }`}>
                    {i + 1}
                  </div>
                  <div className={`h-1 flex-1 rounded-full transition-all ${
                    steps.indexOf(s) < current ? "bg-primary" : "bg-border"
                  }`} />
                </div>
              );
            })}
            <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${
              step === "confirm" ? "bg-primary text-white" : "bg-white border-2 border-border text-muted-foreground"
            }`}>3</div>
          </div>
        )}

        <AnimatePresence mode="wait">

          {/* STEP 1: Select service */}
          {step === "select" && (
            <motion.div
              key="select"
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -30 }}
              transition={{ duration: 0.3 }}
            >
              <div className="bg-white rounded-3xl shadow-lg border border-border/50 p-8">
                <h2 className="text-2xl font-bold text-foreground mb-2">Изберете услуга</h2>
                <p className="text-muted-foreground mb-6">Изберете каква транзакция искате да направите.</p>

                <div className="space-y-3">
                  {services.map((svc) => {
                    const Icon = svc.icon;
                    const isSelected = selectedService.id === svc.id;
                    return (
                      <button
                        key={svc.id}
                        onClick={() => setSelectedService(svc)}
                        className={`w-full flex items-center gap-4 p-4 rounded-2xl border-2 transition-all text-left ${
                          isSelected
                            ? "border-primary bg-primary/5 shadow-sm"
                            : "border-border hover:border-primary/40 hover:bg-secondary/30"
                        }`}
                      >
                        <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${isSelected ? 'bg-primary/10' : 'bg-secondary'}`}>
                          <Icon className={`w-6 h-6 ${isSelected ? svc.color : 'text-muted-foreground'}`} />
                        </div>
                        <div className="flex-1">
                          <p className="font-semibold text-foreground">{svc.label}</p>
                          {svc.price > 0 && (
                            <p className="text-sm text-muted-foreground mt-0.5">{svc.price.toFixed(2)} лв./мес.</p>
                          )}
                        </div>
                        <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                          isSelected ? "border-primary" : "border-border"
                        }`}>
                          {isSelected && <div className="w-2.5 h-2.5 rounded-full bg-primary" />}
                        </div>
                      </button>
                    );
                  })}
                </div>

                {/* Custom amount for bill payment */}
                {selectedService.id === "bill" && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    className="mt-5"
                  >
                    <label className="text-sm font-semibold text-foreground block mb-2">Сума за плащане (лв.)</label>
                    <input
                      type="number"
                      min="1"
                      step="0.01"
                      value={customAmount}
                      onChange={(e) => setCustomAmount(e.target.value)}
                      className="w-full px-4 py-3 rounded-xl border border-border focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all text-lg font-bold"
                      placeholder="0.00"
                    />
                  </motion.div>
                )}

                <div className="mt-8 pt-6 border-t border-border/50 flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Дължима сума</p>
                    <p className="text-3xl font-extrabold text-foreground">{amount.toFixed(2)} <span className="text-lg font-semibold text-muted-foreground">лв.</span></p>
                  </div>
                  <button
                    onClick={() => setStep("details")}
                    disabled={amount <= 0}
                    className="px-8 py-4 rounded-xl bg-primary text-white font-bold shadow-lg shadow-primary/25 hover:shadow-xl hover:-translate-y-0.5 transition-all disabled:opacity-50 disabled:transform-none"
                  >
                    Продължи
                  </button>
                </div>
              </div>
            </motion.div>
          )}

          {/* STEP 2: Card details */}
          {step === "details" && (
            <motion.div
              key="details"
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -30 }}
              transition={{ duration: 0.3 }}
            >
              <div className="bg-white rounded-3xl shadow-lg border border-border/50 p-8">
                <div className="flex items-center gap-3 mb-6">
                  <Lock className="w-5 h-5 text-primary" />
                  <h2 className="text-2xl font-bold text-foreground">Данни на картата</h2>
                </div>

                {/* Card preview */}
                <div className="relative h-44 bg-gradient-to-br from-foreground to-foreground/80 rounded-2xl mb-8 p-6 overflow-hidden">
                  <div className="absolute top-0 right-0 w-48 h-48 bg-white/5 rounded-full -translate-y-1/2 translate-x-1/4" />
                  <div className="absolute bottom-0 left-0 w-32 h-32 bg-white/5 rounded-full translate-y-1/2 -translate-x-1/4" />
                  <div className="relative z-10">
                    <div className="flex justify-between items-start mb-6">
                      <div className="w-10 h-7 bg-yellow-400/80 rounded-md" />
                      <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center text-white font-bold text-sm">A1</div>
                    </div>
                    <p className="text-white/50 text-xs tracking-widest font-mono mb-1">НОМЕР НА КАРТА</p>
                    <p className="text-white font-mono text-xl tracking-widest">
                      {cardData.number || "•••• •••• •••• ••••"}
                    </p>
                    <div className="flex justify-between mt-4">
                      <div>
                        <p className="text-white/40 text-xs">КАРТОДЪРЖАТЕЛ</p>
                        <p className="text-white text-sm font-semibold">{cardData.name || "ИМЕ ФАМИЛИЯ"}</p>
                      </div>
                      <div>
                        <p className="text-white/40 text-xs">ДО</p>
                        <p className="text-white text-sm font-semibold">{cardData.expiry || "ММ/ГГ"}</p>
                      </div>
                    </div>
                  </div>
                </div>

                <form onSubmit={(e) => { e.preventDefault(); if (validate()) setStep("confirm"); }} className="space-y-5">
                  <div>
                    <label className="text-sm font-semibold text-foreground block mb-2">Номер на карта</label>
                    <input
                      type="text"
                      inputMode="numeric"
                      value={cardData.number}
                      onChange={(e) => setCardData({ ...cardData, number: formatCard(e.target.value) })}
                      className={`w-full px-4 py-3.5 rounded-xl border bg-background focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all font-mono tracking-widest text-lg ${errors.number ? 'border-destructive' : 'border-border'}`}
                      placeholder="0000 0000 0000 0000"
                    />
                    {errors.number && <p className="text-destructive text-xs mt-1">{errors.number}</p>}
                  </div>

                  <div>
                    <label className="text-sm font-semibold text-foreground block mb-2">Картодържател</label>
                    <input
                      type="text"
                      value={cardData.name}
                      onChange={(e) => setCardData({ ...cardData, name: e.target.value.toUpperCase() })}
                      className={`w-full px-4 py-3.5 rounded-xl border bg-background focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all font-mono tracking-wide ${errors.name ? 'border-destructive' : 'border-border'}`}
                      placeholder="ИВАН ИВАНОВ"
                    />
                    {errors.name && <p className="text-destructive text-xs mt-1">{errors.name}</p>}
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm font-semibold text-foreground block mb-2">Валидна до</label>
                      <input
                        type="text"
                        inputMode="numeric"
                        value={cardData.expiry}
                        onChange={(e) => setCardData({ ...cardData, expiry: formatExpiry(e.target.value) })}
                        className={`w-full px-4 py-3.5 rounded-xl border bg-background focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all font-mono ${errors.expiry ? 'border-destructive' : 'border-border'}`}
                        placeholder="ММ/ГГ"
                      />
                      {errors.expiry && <p className="text-destructive text-xs mt-1">{errors.expiry}</p>}
                    </div>
                    <div>
                      <label className="text-sm font-semibold text-foreground block mb-2">CVV</label>
                      <input
                        type="password"
                        inputMode="numeric"
                        maxLength={4}
                        value={cardData.cvv}
                        onChange={(e) => setCardData({ ...cardData, cvv: e.target.value.replace(/\D/g, "").slice(0, 4) })}
                        className={`w-full px-4 py-3.5 rounded-xl border bg-background focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all font-mono ${errors.cvv ? 'border-destructive' : 'border-border'}`}
                        placeholder="•••"
                      />
                      {errors.cvv && <p className="text-destructive text-xs mt-1">{errors.cvv}</p>}
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-4 rounded-xl bg-primary text-white font-bold shadow-lg shadow-primary/25 hover:shadow-xl hover:-translate-y-0.5 transition-all mt-2"
                  >
                    Прегледай плащането
                  </button>
                </form>
              </div>
            </motion.div>
          )}

          {/* STEP 3: Confirm */}
          {step === "confirm" && (
            <motion.div
              key="confirm"
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -30 }}
              transition={{ duration: 0.3 }}
            >
              <div className="bg-white rounded-3xl shadow-lg border border-border/50 p-8">
                <h2 className="text-2xl font-bold text-foreground mb-6">Потвърдете плащането</h2>

                <div className="bg-secondary/30 rounded-2xl p-6 space-y-4 mb-6">
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground">Услуга</span>
                    <span className="font-semibold text-foreground text-right max-w-[60%]">{selectedService.label}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground">Карта</span>
                    <span className="font-semibold font-mono">•••• •••• •••• {cardData.number.replace(/\s/g, "").slice(-4)}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground">Картодържател</span>
                    <span className="font-semibold">{cardData.name}</span>
                  </div>
                  <div className="border-t border-border/50 pt-4 flex justify-between items-center">
                    <span className="font-bold text-foreground text-lg">Обща сума</span>
                    <span className="text-3xl font-extrabold text-primary">{amount.toFixed(2)} лв.</span>
                  </div>
                </div>

                <div className="flex items-start gap-3 bg-blue-50 border border-blue-200 rounded-xl p-4 mb-6">
                  <Lock className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
                  <p className="text-sm text-blue-700">
                    Плащането се обработва чрез защитена SSL връзка. Данните на вашата карта са криптирани и не се съхраняват.
                  </p>
                </div>

                <form onSubmit={handlePay}>
                  <button
                    type="submit"
                    disabled={loading}
                    className="w-full py-4 rounded-xl bg-primary text-white font-bold text-lg shadow-lg shadow-primary/25 hover:shadow-xl hover:-translate-y-0.5 transition-all disabled:opacity-70 disabled:transform-none flex items-center justify-center gap-3"
                  >
                    {loading ? (
                      <>
                        <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                        Обработване...
                      </>
                    ) : (
                      <>
                        <Lock className="w-5 h-5" />
                        Плати {amount.toFixed(2)} лв.
                      </>
                    )}
                  </button>
                </form>
              </div>
            </motion.div>
          )}

          {/* SUCCESS */}
          {step === "success" && (
            <motion.div
              key="success"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, type: "spring" }}
            >
              <div className="bg-white rounded-3xl shadow-lg border border-border/50 p-10 text-center">
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
                  className="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6"
                >
                  <CheckCircle2 className="w-14 h-14 text-green-600" />
                </motion.div>
                <h2 className="text-3xl font-extrabold text-foreground mb-3">Плащането е успешно!</h2>
                <p className="text-muted-foreground mb-2">Транзакция #{Math.floor(Math.random() * 9000000) + 1000000}</p>
                <p className="text-muted-foreground mb-8">
                  Платена сума: <span className="font-bold text-foreground">{amount.toFixed(2)} лв.</span>
                </p>
                <div className="bg-secondary/30 rounded-2xl p-5 mb-8 text-left space-y-3">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Услуга</span>
                    <span className="font-medium text-foreground">{selectedService.label}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Карта</span>
                    <span className="font-medium font-mono">•••• {cardData.number.replace(/\s/g, "").slice(-4)}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Дата</span>
                    <span className="font-medium">{new Date().toLocaleDateString("bg-BG", { day: "2-digit", month: "2-digit", year: "numeric" })}</span>
                  </div>
                </div>
                <p className="text-sm text-muted-foreground mb-6">Ще получите потвърждение на имейл в рамките на няколко минути.</p>
                <Link
                  href="/"
                  className="inline-flex px-8 py-4 rounded-xl bg-primary text-white font-bold shadow-lg shadow-primary/25 hover:shadow-xl hover:-translate-y-0.5 transition-all"
                >
                  Обратно към началото
                </Link>
              </div>
            </motion.div>
          )}

        </AnimatePresence>
      </div>
    </div>
  );
}
