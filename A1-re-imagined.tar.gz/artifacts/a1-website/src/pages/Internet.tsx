import { PageLayout } from "@/components/layout/PageLayout";
import { PremiumCard } from "@/components/ui/PremiumCard";
import { Wifi, Home, Router, ShieldCheck } from "lucide-react";
import { motion } from "framer-motion";
import { Link } from "wouter";

export default function Internet() {
  return (
    <PageLayout>
      <section className="relative py-24 lg:py-32 overflow-hidden bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-blue-500/10 text-blue-600 font-semibold text-sm mb-6 border border-blue-500/20">
                <Wifi className="w-4 h-4" />
                Оптична мрежа
              </div>
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-foreground leading-[1.1] mb-6">
                Гигабитова скорост за умния ви дом.
              </h1>
              <p className="text-lg sm:text-xl text-muted-foreground mb-10 text-balance leading-relaxed">
                Безпроблемен стрийминг, игри без забавяне и мигновени изтегляния. Добре дошли в бъдещето на домашния интернет с A1 Fiber.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="relative"
            >
              <img 
                src="https://images.unsplash.com/photo-1544197150-b99a580bb7a8?w=800&q=80" 
                alt="Оптичен интернет" 
                className="rounded-3xl shadow-2xl object-cover h-[500px] w-full"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent rounded-3xl" />
              <div className="absolute bottom-8 left-8 right-8 glass p-6 rounded-2xl flex items-center justify-between">
                <div>
                  <p className="text-white/80 text-sm font-medium uppercase tracking-wider mb-1">Максимална скорост</p>
                  <p className="text-3xl font-bold text-white">1000 Mbps</p>
                </div>
                <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-md">
                  <Router className="w-6 h-6 text-white" />
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      <section className="py-24 bg-white border-t border-border/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Изберете вашата скорост</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">Всички планове включват премиум Wi-Fi 6 рутер и безплатна професионална инсталация.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { speed: "300", price: "22.99", desc: "За ежедневно сърфиране и HD стрийминг." },
              { speed: "500", price: "27.99", desc: "Перфектно за множество устройства и 4K стрийминг.", popular: true },
              { speed: "1000", price: "34.99", desc: "Максимална производителност за игри и мащабни изтегляния." }
            ].map((plan, i) => (
              <PremiumCard key={i} highlighted={plan.popular} delay={i * 0.1}>
                <div className="flex items-center justify-between mb-8">
                  <div>
                    <h3 className="text-4xl font-extrabold text-foreground">{plan.speed}</h3>
                    <p className="text-muted-foreground font-medium uppercase tracking-wider text-sm mt-1">Mbps изтегляне</p>
                  </div>
                  <Home className={`w-8 h-8 ${plan.popular ? 'text-primary' : 'text-foreground/30'}`} />
                </div>
                <p className="text-foreground/70 mb-8 h-12">{plan.desc}</p>
                
                <div className="border-t border-border/50 pt-6 mb-8">
                  <div className="flex items-baseline gap-2">
                    <span className="text-3xl font-bold text-foreground">{plan.price}</span>
                    <span className="text-muted-foreground font-medium">лв. / мес.</span>
                  </div>
                </div>

                <ul className="space-y-3 mb-8">
                  <li className="flex items-center gap-2 text-sm text-foreground/80"><Router className="w-4 h-4 text-primary" /> Безплатен Wi-Fi 6 рутер</li>
                  <li className="flex items-center gap-2 text-sm text-foreground/80"><ShieldCheck className="w-4 h-4 text-primary" /> Net Protect включен</li>
                </ul>

                <Link
                  href="/transaction"
                  className={`w-full py-3.5 rounded-xl font-bold transition-all text-center block ${
                    plan.popular ? 'bg-primary text-white shadow-lg hover:-translate-y-1' : 'bg-secondary text-foreground hover:bg-border'
                  }`}
                >
                  Избери {plan.speed} Mbps
                </Link>
              </PremiumCard>
            ))}
          </div>
        </div>
      </section>
    </PageLayout>
  );
}
