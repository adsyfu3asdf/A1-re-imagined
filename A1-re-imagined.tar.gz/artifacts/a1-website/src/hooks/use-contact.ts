import { useMutation } from "@tanstack/react-query";
import { z } from "zod";

// Simulated API integration for the contact form
// In a real app, this would use api.contact.path from @shared/routes

export const contactSchema = z.object({
  name: z.string().min(2, "Name is required"),
  email: z.string().email("Valid email is required"),
  subject: z.string().min(5, "Subject is required"),
  message: z.string().min(10, "Message must be at least 10 characters"),
});

export type ContactInput = z.infer<typeof contactSchema>;

export function useSubmitContact() {
  return useMutation({
    mutationFn: async (data: ContactInput) => {
      // Validate locally first
      contactSchema.parse(data);
      
      // Simulate network request
      await new Promise((resolve) => setTimeout(resolve, 1500));
      
      // Simulate successful submission
      return { success: true, message: "Message sent successfully" };
    },
  });
}
