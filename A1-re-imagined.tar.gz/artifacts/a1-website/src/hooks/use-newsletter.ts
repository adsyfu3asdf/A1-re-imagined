import { useMutation } from "@tanstack/react-query";

export function useSubscribeNewsletter() {
  return useMutation({
    mutationFn: async (email: string) => {
      if (!email || !email.includes('@')) {
        throw new Error("Please enter a valid email address");
      }
      
      // Simulate network request
      await new Promise((resolve) => setTimeout(resolve, 1000));
      
      return { success: true };
    },
  });
}
