import { Link } from "wouter";
import { Facebook, Twitter, Instagram, Linkedin, Youtube, ArrowRight } from "lucide-react";
import { useSubscribeNewsletter } from "@/hooks/use-newsletter";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

export function Footer() {
  const [email, setEmail] = useState("");
  const subscribe = useSubscribeNewsletter();
  const { toast } = useToast();

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    subscribe.mutate(email, {
      onSuccess: () => {
        toast({
          title: "Абониран!",
          description: "Успешно се абонирахте за нашия бюлетин.",
        });
        setEmail("");
      },
      onError: (err) => {
        toast({
          title: "Грешка",
          description: err.message,
          variant: "destructive",
        });
      }
    });
  };

  return (
    <footer className="bg-foreground text-background pt-24 pb-12 mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-12 lg:gap-8 mb-16">
          
          <div className="lg:col-span-2">
            <Link href="/" className="flex items-center gap-2 mb-6">
              <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center text-primary-foreground font-bold text-xl tracking-tighter">
                A1
              </div>
              <span className="font-semibold tracking-tight text-xl text-background">
                България
              </span>
            </Link>
            <p className="text-background/60 mb-8 max-w-sm text-balance">
              Подобряваме вашия цифров живот с безпроблемна свързаност, авангардни технологии и първокласни услуги в цяла България.
            </p>
            <form onSubmit={handleSubscribe} className="flex gap-2 max-w-sm">
              <input 
                type="email" 
                placeholder="Въведете вашия имейл"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="bg-white/10 border border-white/20 rounded-xl px-4 py-3 w-full text-background placeholder:text-background/40 focus:outline-none focus:border-primary transition-colors"
              />
              <button 
                type="submit"
                disabled={subscribe.isPending}
                className="bg-primary hover:bg-primary/90 text-white px-4 py-3 rounded-xl transition-colors disabled:opacity-50"
              >
                {subscribe.isPending ? "..." : <ArrowRight className="w-5 h-5" />}
              </button>
            </form>
          </div>

          <div>
            <h4 className="font-semibold text-lg mb-6 text-white">Услуги</h4>
            <ul className="space-y-4 text-background/60">
              <li><Link href="/mobile" className="hover:text-primary transition-colors">Мобилни планове</Link></li>
              <li><Link href="/internet" className="hover:text-primary transition-colors">Домашен интернет</Link></li>
              <li><Link href="/tv" className="hover:text-primary transition-colors">A1 Xplore TV</Link></li>
              <li><Link href="/business" className="hover:text-primary transition-colors">Бизнес решения</Link></li>
              <li><Link href="#" className="hover:text-primary transition-colors">Смарт устройства</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold text-lg mb-6 text-white">Поддръжка</h4>
            <ul className="space-y-4 text-background/60">
              <li><Link href="/contact" className="hover:text-primary transition-colors">Свържете се с нас</Link></li>
              <li><Link href="#" className="hover:text-primary transition-colors">Намери магазин</Link></li>
              <li><Link href="#" className="hover:text-primary transition-colors">Често задавани въпроси</Link></li>
              <li><Link href="#" className="hover:text-primary transition-colors">Мрежово покритие</Link></li>
              <li><Link href="/transaction" className="hover:text-primary transition-colors">Плащане на сметка</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold text-lg mb-6 text-white">Компания</h4>
            <ul className="space-y-4 text-background/60">
              <li><Link href="#" className="hover:text-primary transition-colors">За A1</Link></li>
              <li><Link href="#" className="hover:text-primary transition-colors">Кариери</Link></li>
              <li><Link href="#" className="hover:text-primary transition-colors">Новини и медия</Link></li>
              <li><Link href="#" className="hover:text-primary transition-colors">Устойчивост</Link></li>
              <li><Link href="#" className="hover:text-primary transition-colors">Investor Relations</Link></li>
            </ul>
          </div>

        </div>

        <div className="border-t border-white/10 pt-8 flex flex-col md:flex-row items-center justify-between gap-6">
          <p className="text-background/40 text-sm">
            © {new Date().getFullYear()} A1 България. Всички права запазени.
          </p>
          <div className="flex items-center gap-4">
            <a href="#" className="text-background/40 hover:text-white transition-colors"><Facebook className="w-5 h-5" /></a>
            <a href="#" className="text-background/40 hover:text-white transition-colors"><Twitter className="w-5 h-5" /></a>
            <a href="#" className="text-background/40 hover:text-white transition-colors"><Instagram className="w-5 h-5" /></a>
            <a href="#" className="text-background/40 hover:text-white transition-colors"><Linkedin className="w-5 h-5" /></a>
            <a href="#" className="text-background/40 hover:text-white transition-colors"><Youtube className="w-5 h-5" /></a>
          </div>
          <div className="flex gap-6 text-sm text-background/40">
            <a href="#" className="hover:text-white transition-colors">Поверителност</a>
            <a href="#" className="hover:text-white transition-colors">Условия</a>
            <a href="#" className="hover:text-white transition-colors">Бисквитки</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
