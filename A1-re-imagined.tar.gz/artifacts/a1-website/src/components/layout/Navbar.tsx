import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { Menu, X, Search, User, Globe } from "lucide-react";

const navLinks = [
  { name: "Мобилни", href: "/mobile" },
  { name: "Интернет", href: "/internet" },
  { name: "TV", href: "/tv" },
  { name: "Бизнес", href: "/business" },
  { name: "Контакти", href: "/contact" },
];

export function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [location] = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    setMobileMenuOpen(false);
  }, [location]);

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          isScrolled ? "py-3 glass" : "py-5 bg-transparent"
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center gap-2 group">
              <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center text-primary-foreground font-bold text-xl tracking-tighter shadow-lg shadow-primary/20 group-hover:scale-105 transition-transform duration-300">
                A1
              </div>
              <span className={`font-semibold tracking-tight text-lg hidden sm:block ${isScrolled ? 'text-foreground' : 'text-foreground'}`}>
                България
              </span>
            </Link>

            <nav className="hidden md:flex items-center gap-8">
              {navLinks.map((link) => {
                const isActive = location === link.href;
                return (
                  <Link
                    key={link.name}
                    href={link.href}
                    className={`text-sm font-medium transition-colors hover:text-primary relative py-1 ${
                      isActive ? "text-primary" : "text-foreground/80"
                    }`}
                  >
                    {link.name}
                    {isActive && (
                      <motion.div
                        layoutId="navbar-indicator"
                        className="absolute bottom-0 left-0 right-0 h-0.5 bg-primary rounded-full"
                        initial={false}
                        transition={{ type: "spring", stiffness: 300, damping: 30 }}
                      />
                    )}
                  </Link>
                );
              })}
            </nav>

            <div className="hidden md:flex items-center gap-4">
              <button className="p-2 text-foreground/70 hover:text-primary transition-colors rounded-full hover:bg-secondary">
                <Globe className="w-5 h-5" />
              </button>
              <button className="p-2 text-foreground/70 hover:text-primary transition-colors rounded-full hover:bg-secondary">
                <Search className="w-5 h-5" />
              </button>
              <Link
                href="/login"
                className="flex items-center gap-2 px-5 py-2.5 bg-foreground text-background rounded-full text-sm font-semibold hover:bg-foreground/90 transition-all hover:shadow-lg hover:-translate-y-0.5"
              >
                <User className="w-4 h-4" />
                Моят A1
              </Link>
            </div>

            <button
              className="md:hidden p-2 text-foreground"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </header>

      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 z-40 bg-background/95 backdrop-blur-xl pt-24 pb-8 px-4 flex flex-col"
          >
            <nav className="flex flex-col gap-4 text-center mt-8">
              {navLinks.map((link) => (
                <Link
                  key={link.name}
                  href={link.href}
                  className={`text-2xl font-semibold py-3 border-b border-border/50 ${
                    location === link.href ? "text-primary" : "text-foreground"
                  }`}
                >
                  {link.name}
                </Link>
              ))}
            </nav>
            <div className="mt-auto flex flex-col gap-4">
              <button className="flex items-center justify-center gap-2 py-4 bg-secondary rounded-xl font-medium">
                <Globe className="w-5 h-5" /> Български
              </button>
              <Link
                href="/login"
                className="flex items-center justify-center gap-2 py-4 bg-primary text-primary-foreground rounded-xl font-bold shadow-lg shadow-primary/25"
              >
                <User className="w-5 h-5" /> Моят A1 Акаунт
              </Link>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
