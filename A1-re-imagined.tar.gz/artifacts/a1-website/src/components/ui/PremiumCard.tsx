import { ReactNode } from "react";
import { motion } from "framer-motion";

interface PremiumCardProps {
  children: ReactNode;
  className?: string;
  delay?: number;
  highlighted?: boolean;
}

export function PremiumCard({ children, className = "", delay = 0, highlighted = false }: PremiumCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-50px" }}
      transition={{ duration: 0.6, delay, ease: "easeOut" }}
      className={`
        bg-card rounded-3xl p-8 relative overflow-hidden
        transition-all duration-300 ease-out
        hover:-translate-y-2 hover:shadow-2xl hover:shadow-primary/5
        ${highlighted ? 'border-2 border-primary shadow-xl shadow-primary/10' : 'border border-border/50 shadow-lg shadow-black/5'}
        ${className}
      `}
    >
      {highlighted && (
        <div className="absolute top-0 right-0 w-32 h-32 bg-primary/10 rounded-bl-full -z-10 blur-2xl" />
      )}
      <div className="relative z-10">
        {children}
      </div>
    </motion.div>
  );
}
